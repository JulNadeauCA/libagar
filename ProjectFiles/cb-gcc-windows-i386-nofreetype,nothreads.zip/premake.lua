--
-- Do not edit!
-- This file was generated from Makefile by BSDbuild 2.1.
--
-- To regenerate this file, get the latest BSDbuild release from
-- http://hypertriton.com/bsdbuild/, the latest Premake release
-- (v3 series) from http://premake.sourceforge.net/, and execute:
--
--     $ make proj
--
project.name = "Agar"
project.guid = "93733df2-c743-489e-bc9f-f22aee00d787"
dopackage("core")
dopackage("agar-core-config")
dopackage("gui")
dopackage("agar-config")
dopackage("vg")
dopackage("agar-vg-config")
dopackage("rg")
dopackage("agar-rg-config")
dopackage("map")
dopackage("agar-map-config")
dopackage("sc")
dopackage("agar-sc-config")
dopackage("dev")
dopackage("agar-dev-config")
dopackage("net")
dopackage("agar-net-config")
dopackage("po")
