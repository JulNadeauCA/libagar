#ifndef _MK_HAVE_LIMITS_H
#define _MK_HAVE_LIMITS_H "yes"
#endif
