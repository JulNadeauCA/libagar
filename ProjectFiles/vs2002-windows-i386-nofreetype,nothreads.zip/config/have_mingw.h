#undef HAVE_MINGW
