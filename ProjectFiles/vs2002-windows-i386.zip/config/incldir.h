#ifndef INCLDIR
#define INCLDIR "/usr/local/include/agar"
#endif
