#ifndef HAVE_VSNPRINTF
#define HAVE_VSNPRINTF "yes"
#endif
