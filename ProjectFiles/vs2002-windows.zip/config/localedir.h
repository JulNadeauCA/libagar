#ifndef LOCALEDIR
#define LOCALEDIR "/usr/local/share/agar/locale"
#endif
