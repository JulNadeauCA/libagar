#ifndef PTHREADS_CFLAGS
#define PTHREADS_CFLAGS ""
#endif
