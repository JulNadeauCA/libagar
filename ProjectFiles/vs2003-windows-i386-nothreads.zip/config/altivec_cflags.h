#ifndef ALTIVEC_CFLAGS
#define ALTIVEC_CFLAGS ""
#endif
