#ifndef TTFDIR
#define TTFDIR "/usr/local/share/agar/fonts"
#endif
