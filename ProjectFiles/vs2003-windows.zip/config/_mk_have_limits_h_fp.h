#ifndef _MK_HAVE_LIMITS_H_FP
#define _MK_HAVE_LIMITS_H_FP "yes"
#endif
