    _       _       _     ___  
  / _ \   / _ \   / _ \  |  _ \ 
 | |_| | | (_| | | |_| | | |_) |
 |_| |_|  \__, | |_| |_| |_| |_|
          |___/                 

What is it?
-----------
Agar is a type of sugar polymer obtained from seaweed and red algae. Agar
becomes gelatinous in water and is primarly used as a culture medium for
microbiological work. Agar is also the name of an open source toolkit for
portable graphical applications.

Agar consists of two libraries: Agar-Core and Agar-GUI.

Agar-Core implements an object system that provides support for object
oriented programming under any language, including ANSI C. Agar-Core also
provides portable interfaces to some operating system services.

Agar-GUI is an extensive GUI toolkit designed to work with anything that
has a display and a pointing device (or keyboard). Currently, it provides
drivers for SDL and OpenGL. The OpenGL mode makes efficient use of hardware
acceleration if it is available.

Documentation
-------------
This package includes API documentation in the form of manual pages. You
can also read the manual pages online or download the pages in HTML or
printable format from the Agar website at http://libagar.org/docs/.

Availability
------------
You can download the most recent Agar version from the Agar home page
at http://libagar.org/.

Portability
-----------
Agar is portable to many different platforms, including FreeBSD, IRIX,
Linux, MacOS Classic, MacOS X, NetBSD, OpenBSD and Windows. It has even
been ported to various consoles such as the GP2x, Nintendo Gamecube/Wii,
Sony Playstation2 and Nintendo DS.

For the list of official ports, see http://libagar.org/portable.html.

License
-------
Agar is freely distributable under the terms the "revised" BSD license,
without an advertising clause. See: http://libagar.org/license.html.

Acknowledgements
----------------
See: http://libagar.org/credits.html.

Other libraries based on Agar
-----------------------------
Here are some useful libraries are based on Agar-Core and Agar-GUI. Some of
them are bundled with this source distribution, but you need to explicitely
link your application against them.

Agar-DEV	Developer/debugging tools (bundled, use `agar-dev-config`)
Agar-VG		Vector graphics library (bundled, use `agar-vg-config`)
Agar-SC		Scientific computing utilities (bundled, use `agar-sc-config`)
Agar-RG		2D graphic rendering/edition (bundled, use `agar-rg-config`)
Agar-MAP	2D game levels/edition (bundled, use `agar-map-config`)
FreeSG		3D engine (see http://freesg.org/)
CADTools	CAD/CAM libraries (see http://hypertriton.com/cadtools/)

