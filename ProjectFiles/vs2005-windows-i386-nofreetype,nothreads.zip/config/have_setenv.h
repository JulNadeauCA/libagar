#ifndef HAVE_SETENV
#define HAVE_SETENV "yes"
#endif
