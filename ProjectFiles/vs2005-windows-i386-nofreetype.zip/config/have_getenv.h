#ifndef HAVE_GETENV
#define HAVE_GETENV "yes"
#endif
