#ifndef VIEW_8BPP
#define VIEW_8BPP "1"
#endif
