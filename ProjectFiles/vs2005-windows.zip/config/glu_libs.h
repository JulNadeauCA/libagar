#ifndef GLU_LIBS
#define GLU_LIBS " -lGLU"
#endif
