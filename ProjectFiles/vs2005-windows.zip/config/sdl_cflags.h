#ifndef SDL_CFLAGS
#define SDL_CFLAGS "-I/usr/include/SDL -D_GNU_SOURCE=1 -D_REENTRANT"
#endif
