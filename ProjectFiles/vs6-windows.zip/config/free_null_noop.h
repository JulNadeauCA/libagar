#ifndef free_null_noop
#define free_null_noop "yes"
#endif
