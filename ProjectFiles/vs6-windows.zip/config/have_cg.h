#undef HAVE_CG
