#ifndef RELEASE
#define RELEASE "The Birth Of An Era Obscured By Sulfur And Flames"
#endif
