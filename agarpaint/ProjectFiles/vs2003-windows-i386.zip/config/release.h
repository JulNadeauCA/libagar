#ifndef RELEASE
#define RELEASE "The Ecstatic Spiral to Hell"
#endif
