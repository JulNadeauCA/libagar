#ifndef AGAR_RG_LIBS
#define AGAR_RG_LIBS "ag_rg"
#endif
