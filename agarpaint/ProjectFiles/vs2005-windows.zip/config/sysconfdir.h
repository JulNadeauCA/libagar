#ifndef SYSCONFDIR
#define SYSCONFDIR "."
#endif /* SYSCONFDIR */
