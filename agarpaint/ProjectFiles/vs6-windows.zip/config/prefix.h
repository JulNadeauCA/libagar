#ifndef PREFIX
#define PREFIX "."
#endif /* PREFIX */
