#ifndef RELEASE
#define RELEASE "Landscapes Turn To Ash"
#endif
