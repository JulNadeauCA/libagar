#ifndef AGAR_MAP_LIBS
#define AGAR_MAP_LIBS "ag_map"
#endif
