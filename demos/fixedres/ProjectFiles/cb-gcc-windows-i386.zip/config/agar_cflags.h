#ifndef AGAR_CFLAGS
#define AGAR_CFLAGS ""
#endif
