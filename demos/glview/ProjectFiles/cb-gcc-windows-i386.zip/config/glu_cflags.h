#ifndef GLU_CFLAGS
#define GLU_CFLAGS ""
#endif
