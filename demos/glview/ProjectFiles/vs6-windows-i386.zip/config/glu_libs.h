#ifndef GLU_LIBS
#define GLU_LIBS "glu32"
#endif
