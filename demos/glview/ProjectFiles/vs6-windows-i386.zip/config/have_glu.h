#ifndef HAVE_GLU
#define HAVE_GLU "yes"
#endif
