--
-- Do not edit!
-- This file was generated from Makefile by BSDbuild 2.1.
--
-- To regenerate this file, get the latest BSDbuild release from
-- http://hypertriton.com/bsdbuild/, the latest Premake release
-- (v3 series) from http://premake.sourceforge.net/, and execute:
--
--     $ make proj
--
project.name = "glview"
package = newpackage()
package.name = "glview"
package.kind = "winexe"
package.guid = "B22C8324-AB8E-417e-9459-9FA0698D45D7"
dofile("configure.lua")
if (hdefs["HAVE_GLU"] ~= nil) then
	table.insert(package.links, { "glu32" })
end
package.files = {
	"glview.c",
}
tinsert(package.includepaths,{"."})
