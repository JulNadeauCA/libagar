#ifndef SHAREDIR
#define SHAREDIR ""
#endif /* SHAREDIR */
