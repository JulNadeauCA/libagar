#ifndef AGAR_SC_LIBS
#define AGAR_SC_LIBS "ag_sc"
#endif
