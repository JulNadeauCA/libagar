#ifndef _MK_HAVE_STDLIB_H
#define _MK_HAVE_STDLIB_H "yes"
#endif
