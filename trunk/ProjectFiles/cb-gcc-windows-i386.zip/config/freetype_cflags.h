#ifndef FREETYPE_CFLAGS
#define FREETYPE_CFLAGS ""
#endif
