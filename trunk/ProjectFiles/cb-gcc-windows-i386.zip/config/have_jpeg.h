#undef HAVE_JPEG
