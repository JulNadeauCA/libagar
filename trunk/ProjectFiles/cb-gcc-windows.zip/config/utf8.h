#ifndef UTF8
#define UTF8 "1"
#endif
