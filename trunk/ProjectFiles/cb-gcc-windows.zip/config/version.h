#ifndef VERSION
#define VERSION "09292007"
#endif
