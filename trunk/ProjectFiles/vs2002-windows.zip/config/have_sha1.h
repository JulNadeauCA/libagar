#undef HAVE_SHA1
