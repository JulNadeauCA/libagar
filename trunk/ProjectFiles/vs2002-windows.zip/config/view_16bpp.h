#ifndef VIEW_16BPP
#define VIEW_16BPP "1"
#endif
