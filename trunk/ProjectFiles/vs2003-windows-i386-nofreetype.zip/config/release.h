#ifndef RELEASE
#define RELEASE "Horrors of the Abysmal Kingdom"
#endif
