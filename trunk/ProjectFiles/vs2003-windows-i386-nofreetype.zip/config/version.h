#ifndef VERSION
#define VERSION "1.3.2rc2"
#endif
