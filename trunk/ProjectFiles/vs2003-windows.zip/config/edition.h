#ifndef EDITION
#define EDITION "1"
#endif
