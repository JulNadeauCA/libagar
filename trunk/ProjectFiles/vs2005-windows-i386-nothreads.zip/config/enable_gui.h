#ifndef ENABLE_GUI
#define ENABLE_GUI "1"
#endif
