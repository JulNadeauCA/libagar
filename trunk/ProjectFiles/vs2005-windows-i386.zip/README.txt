    _       _       _     ___  
  / _ \   / _ \   / _ \  |  _ \ 
 | |_| | | (_| | | |_| | | |_) |
 |_| |_|  \__, | |_| |_| |_| |_|
          |___/                 

What is it?
-----------
Agar is a type of sugar polymer obtained from seaweed and red algae. Agar
becomes gelatinous in water and is primarly used as a culture medium for
microbiological work. Agar is also the name of an open source toolkit for
portable graphical applications. Agar consists of two libraries: Agar-Core
and Agar-GUI.

The Agar-Core library provides a simple object system which allows for a
lightweight, consistent and portable form of object-oriented programming
under multiple languages including C, C++ and Perl (Agar-Core itself is
implemented in C). The main functions of the object system are inheritance,
serialization, virtual functions / events and per-object management of
resources such as timers and threads. A number of portability interfaces
are also provided by Agar-Core.

Agar-GUI is an extensive GUI toolkit designed to work with anything that
has a display and a pointing device (or keyboard). Currently, it provides
drivers for SDL and OpenGL. The OpenGL mode makes efficient use of hardware
acceleration if it is available.

Documentation
-------------
This package includes API documentation in the form of manual pages. You
can also read the manual pages online or download the pages in HTML or
printable format from the Agar website at http://libagar.org/docs/.

Availability
------------
You can download the most recent Agar version from the Agar home page
at http://libagar.org/.

Portability
-----------
Agar is portable to many different platforms, including FreeBSD, IRIX,
Linux, MacOS Classic, MacOS X, NetBSD, OpenBSD and Windows. It has even
been ported to various consoles such as the GP2x, Nintendo Gamecube/Wii,
Sony Playstation2 and Nintendo DS.

For the list of official ports, see http://libagar.org/portable.html.

License
-------
Agar is freely distributable under the terms the "revised" BSD license,
without an advertising clause. See: http://libagar.org/license.html.

Acknowledgements
----------------
See: http://libagar.org/credits.html.

Other libraries based on Agar
-----------------------------
There are a number of useful libraries based on Agar. Some of them are
bundled with this source distribution (Agar-VG, etc), but you will need
to explicitely link your application against them in order to use them.

Agar-VG		Vector graphics library (bundled, use `agar-vg-config`)
Agar-RG		2D graphic rendering/edition (bundled, use `agar-rg-config`)
Agar-MAP	2D game levels/edition (bundled, use `agar-map-config`)
Agar-DEV	Developer/debugging tools (bundled, use `agar-dev-config`)
FreeSG		Math, computational geometry, 3D rendering (http://freesg.org/)
Edacious	Electronics design (http://edacious.hypertriton.com/)
CADTools	Computer-aided design (http://cadtools.hypertriton.com/)

