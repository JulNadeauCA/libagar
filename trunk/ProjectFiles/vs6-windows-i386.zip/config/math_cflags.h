#ifndef MATH_CFLAGS
#define MATH_CFLAGS ""
#endif
