#undef HAVE_64BIT
