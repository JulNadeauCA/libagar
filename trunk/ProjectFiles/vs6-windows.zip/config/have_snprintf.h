#ifndef HAVE_SNPRINTF
#define HAVE_SNPRINTF
#endif
