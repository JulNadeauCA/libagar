#ifndef OPENGL_LIBS
#define OPENGL_LIBS "-L/usr/X11R6/lib -lGL"
#endif
