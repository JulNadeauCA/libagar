#ifndef HAVE_AGAR_RG
#define HAVE_AGAR_RG "yes"
#endif
