#ifndef HAVE_CC_WARNINGS
#define HAVE_CC_WARNINGS "yes"
#endif
