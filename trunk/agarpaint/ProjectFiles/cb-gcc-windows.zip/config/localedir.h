#ifndef LOCALEDIR
#define LOCALEDIR "."
#endif /* LOCALEDIR */
