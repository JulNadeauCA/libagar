--
-- Do not edit!
-- This file was generated from Makefile by BSDbuild 2.1.
--
-- To regenerate this file, get the latest BSDbuild release from
-- http://hypertriton.com/bsdbuild/, the latest Premake release
-- (v3 series) from http://premake.sourceforge.net/, and execute:
--
--     $ make proj
--
project.name = "agarpaint"
package = newpackage()
package.name = "agarpaint"
package.kind = "winexe"
package.guid = "68DBFDA9-4965-4cca-8348-38409D8587A6"
dofile("configure.lua")
tinsert(package.links, { "ag_core", "SDL" })
tinsert(package.links, { "ag_gui", "SDL", "opengl32", "freetype" })
tinsert(package.links,{"ag_map"})
tinsert(package.links,{"ag_rg"})
tinsert(package.links,{"ag_vg"})
tinsert(package.links,{"ag_dev"})
if (hdefs["HAVE_PTHREADS"] ~= nil) then
	if (windows) then
		table.insert(package.links, { "pthreadVC2" })
	else
		table.insert(package.links, { "pthread" })
	end
end
if (hdefs["HAVE_SDL"] ~= nil) then
	tinsert(package.links, { "SDL", "SDLmain" })
end
if (hdefs["HAVE_SDL"] ~= nil) then
	tinsert(package.links, { "SDL", "SDLmain" })
end
if (hdefs["HAVE_OPENGL"] ~= nil) then
	if (windows) then
		tinsert(package.links, { "opengl32" })
	else
		tinsert(package.links, { "GL" })
	end
end
if (hdefs["HAVE_FREETYPE"] ~= nil) then
	table.insert(package.links, { "freetype" })
end
package.files = {
	"agarpaint.c",
}
