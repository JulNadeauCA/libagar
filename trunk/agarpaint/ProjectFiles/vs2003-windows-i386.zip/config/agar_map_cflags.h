#ifndef AGAR_MAP_CFLAGS
#define AGAR_MAP_CFLAGS ""
#endif
