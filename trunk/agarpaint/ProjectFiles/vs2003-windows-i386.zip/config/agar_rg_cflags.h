#ifndef AGAR_RG_CFLAGS
#define AGAR_RG_CFLAGS ""
#endif
