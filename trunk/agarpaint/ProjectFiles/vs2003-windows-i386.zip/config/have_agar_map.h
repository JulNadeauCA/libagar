#ifndef HAVE_AGAR_MAP
#define HAVE_AGAR_MAP "yes"
#endif
