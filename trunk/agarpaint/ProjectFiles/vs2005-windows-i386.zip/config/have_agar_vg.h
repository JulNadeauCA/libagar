#ifndef HAVE_AGAR_VG
#define HAVE_AGAR_VG "yes"
#endif
