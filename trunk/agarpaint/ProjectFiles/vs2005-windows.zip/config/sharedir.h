#ifndef SHAREDIR
#define SHAREDIR "."
#endif
