#ifndef AGAR_LIBS
#define AGAR_LIBS "ag_core ag_gui"
#endif
