--
-- Do not edit!
-- This file was generated from Makefile by BSDbuild 2.1.
--
-- To regenerate this file, get the latest BSDbuild release from
-- http://hypertriton.com/bsdbuild/, the latest Premake release
-- (v3 series) from http://premake.sourceforge.net/, and execute:
--
--     $ make proj
--
project.name = "plotting"
package = newpackage()
package.name = "plotting"
package.kind = "winexe"
package.guid = "19dbbfcd-9e00-46ed-9f5c-7934652a6b9b"
dofile("configure.lua")
tinsert(package.links, { "ag_core", "SDL" })
tinsert(package.links, { "ag_core" })
tinsert(package.links, { "ag_gui", "SDL", "opengl32", "freetype" })
if (hdefs["HAVE_PTHREADS"] ~= nil) then
	if (windows) then
		table.insert(package.links, { "pthreadVC2" })
	else
		table.insert(package.links, { "pthread" })
	end
end
if (hdefs["HAVE_SDL"] ~= nil) then
	tinsert(package.links, { "SDL", "SDLmain" })
end
if (hdefs["HAVE_SDL"] ~= nil) then
	tinsert(package.links, { "SDL", "SDLmain" })
end
if (hdefs["HAVE_OPENGL"] ~= nil) then
	if (windows) then
		tinsert(package.links, { "opengl32" })
	else
		tinsert(package.links, { "GL" })
	end
end
if (hdefs["HAVE_FREETYPE"] ~= nil) then
	table.insert(package.links, { "freetype" })
end
package.files = {
	"plotting.c",
}
tinsert(package.includepaths,{"."})
