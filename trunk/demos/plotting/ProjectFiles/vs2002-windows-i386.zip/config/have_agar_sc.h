#ifndef HAVE_AGAR_SC
#define HAVE_AGAR_SC "yes"
#endif
