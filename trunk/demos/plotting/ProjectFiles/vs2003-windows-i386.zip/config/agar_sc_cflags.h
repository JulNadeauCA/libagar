#ifndef AGAR_SC_CFLAGS
#define AGAR_SC_CFLAGS ""
#endif
