#ifndef SDL_CFLAGS
#define SDL_CFLAGS ""
#endif
