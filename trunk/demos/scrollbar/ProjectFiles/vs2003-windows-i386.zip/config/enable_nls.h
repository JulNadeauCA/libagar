#undef ENABLE_NLS
