#ifndef OPENGL_LIBS
#define OPENGL_LIBS "opengl32"
#endif
