#ifndef HAVE_OPENGL
#define HAVE_OPENGL "yes"
#endif
